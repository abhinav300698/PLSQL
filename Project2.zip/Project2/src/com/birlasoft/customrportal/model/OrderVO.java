
package com.birlasoft.customrportal.model;
// VALUE OBJECT  -> Domain Object -> TRANSFER OBJECT
// POJO

/*     class:OrderVO  
 *     get/set for  productId / productName / productColor
 *     getOrderId() method to get ID of product and setOrderId method() for updating value for ID
 *     getproductName1() method  get Name of product and setProductName1 method() for updating value for Name
 *     getproductColor() method  get Color of product and setProductColor method() for updating value for Color
 */
public class OrderVO implements Comparable<OrderVO>{
	
public OrderVO(String productId) {
		
	super();
	this.productId=productId;
		
		 
	}
	
	private String productId;
	private String productName;
	private String productColor;
	
	public OrderVO(String productId, String  productName,
			String productColor) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productColor = productColor;
	
	
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getproductName1() {
		return productName;
	}
	public void setproductName1(String customerName) {
		this.productName = customerName;
	}
	public String getproductColor() {
		return productColor;
	}
	public void setproductColor(String contactNumber) {
		this.productColor = contactNumber;
	}
	//@Override // represent object in string format
	public String toString() {
		return  "\nproduct Id      :"+productId +
				"\nProduct Name    :"+ productName +
				"\nProduct Color   :" + productColor + "";
	}
	@Override // represent object in string format...Displaying the values in order to productName
	public int compareTo(OrderVO secondObj	) {
		
		int result=0;
		String firstObjName= this.getproductName1();
		   String secondObjName= secondObj.getproductName1();
		
		   result=  firstObjName.compareTo(secondObjName);
		   
		return result;
	}
	
	 

}
