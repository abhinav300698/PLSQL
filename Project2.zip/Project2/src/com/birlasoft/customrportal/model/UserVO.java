
package com.birlasoft.customrportal.model;
// VALUE OBJECT  -> Domain Object -> TRANSFER OBJECT
// POJO

public class UserVO implements Comparable<UserVO>{
	/*    class:ProductVO  
	*     get/set for  userId / productName / productPrice
	*     getuserId() method to get ID of user and setuserId method() for updating value for ID
	*     getUserName() method  get Name of user and setgetUserName method() for updating value for Name
	*     getContactNumber() method  get ContactNumberof user and setproductPrice method() for updating value for ContactNumber
	*/
	private String userId;
	private String userName;
	private String userNumber;
	public UserVO(String userId) {
		super();
		this.userId=userId;
		 
	}
	public UserVO(String userId, String userName,
			String userNumber) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userNumber = userNumber;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getContactNumber() {
		return userNumber;
	}
	public void setContactNumber(String userNumber) {
		this.userNumber = userNumber;
	}
	//@Override // represent object in string format
	public String toString() {
		return "\nUserId         :" + userId + 
				"\nUserName       :"+ userName +
				"\nContactNumber  :" + userNumber + "";
	}
	@Override
	public int compareTo(UserVO secondObj	) {
		
		int result=0;
		String firstObjName= this.getUserId();
		   String secondObjName= secondObj.getUserId();
		
		   result=  firstObjName.compareTo(secondObjName);
		   
		return result;
	}
	
	 

}
