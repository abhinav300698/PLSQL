package com.birlasoft.customrportal.model;


public class LoginVO {

	/*     class:LoginVO  
	 *     get/set for userName /password
	 *     getPassword() method  
	 *     getUSerNAme() method   
	 */
	private String userName;
	private String Password;
	
	
	public String getUserName() {
		return userName;
	}
	public LoginVO(String userName, String password) {
		super();
		this.userName = userName;
		Password = password;
	}
	public LoginVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		System.out.println("------------------------------------------------------------------");	 
		return "\nLOGIN DETAILS:\nUserName : " + userName + "    Password : " + Password + "";
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

}
