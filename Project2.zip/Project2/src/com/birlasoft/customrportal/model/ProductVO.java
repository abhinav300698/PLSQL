package com.birlasoft.customrportal.model;
//VALUE OBJECT  -> Domain Object -> TRANSFER OBJECT
//POJO


public class ProductVO implements Comparable<ProductVO>{
	
	/*    class:ProductVO  
	*     get/set for  productId / productName / productPrice
	*     getproductId() method to get ID of product and setproductId method() for updating value for ID
	*     getproductName() method  get Name of product and setProductName method() for updating value for Name
	*     getproductPrice() method  get Price of product and setproductPrice method() for updating value for productPrice
	*/
	
	private String productId;
	private String productName;
	private String productPrice;
	public ProductVO() {
		super();
		 
	}
	public ProductVO(String productId, String productName,
			String productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
	}
	public ProductVO(String productId) {
		
		this.productId=productId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	//@Override // represent object in string format
	public String toString() {
		return "\nProductId     :"+productId +
			  " \nProductName   :"+productName + 
			  "\nProduct Price :"+productPrice + "";
	}
	@Override
	public int compareTo(ProductVO secondObj	) {
		
		int result=0;
		String firstObjName= this.getProductId();
		   String secondObjName= secondObj.getProductId();
		
		   result=  firstObjName.compareTo(secondObjName);
		   
		return result;
	}
	
	 

}
