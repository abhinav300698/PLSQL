package com.birlasoft.customrportal.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 *   getDBConnection() method : to connect with the database
 *   Database name: PRANJAL
 *   Port number: 1521
 *   Username- hr  password- oracle123
 *   closeDBConnection() method : to close database connection
 */
 
import org.birlasoft.customerportal.dao.CustomerDatabaseException;

public class ConnectionDB {
	
	private static Connection  con;
	public static void loadDrivers() throws CustomerDatabaseException
	{
		 try
		 {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		 }
		 catch(ClassNotFoundException e)
		 {
			 throw new CustomerDatabaseException("problem in loading drivers");
			 
		 }
	}
	
  public static  Connection  getDBConnection() throws CustomerDatabaseException 
  {
	  try
	  {
	  String url="jdbc:oracle:thin:@localhost:1521:PRANJAL" ;
	  con = DriverManager.getConnection(url,"hr","oracle123");
	  }
	  catch(SQLException e)
	  {
		  throw new CustomerDatabaseException("problem in loading drivers..check database name, username and password credentials!!");
			 
		  
	  }
	  return con;
  }
	
  public static void closeDBConnection(Connection con)  
  {
	  try
	  {
	   if(con!=null)
	   {
		   con.close();
	   }
	  }
	  catch(SQLException e)
	  {
		  System.out.println("problem in closing connection"+e);
	  }
  }
  
  
  
	
}
