package com.birlasoft.customrportal.service;

import com.birlasoft.customrportal.model.LoginVO;

public class LoginBO {
	
	public static boolean loginValidate(LoginVO  login)
	{
		boolean loginCheck=false;
		 
			if(login.getPassword().length()>3) //Checking the length of password should be less than or equal to 3
				{
				loginCheck=true;
				
				
				}
			else
			{
				System.out.println("USERNAME OR PASSWORD CANT BE BLANK ...THE LENGTH OF USERNAME OR PASSWORD IS TOO SHORT");
			}
					
			System.out.println("value:"+loginCheck); // returning the logincheck value i.e true
		 
	return loginCheck;	
	}

}
