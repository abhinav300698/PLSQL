package org.birlasoft.customerportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.birlasoft.customrportal.model.UserVO;
import com.birlasoft.customrportal.util.ConnectionDB;

public class ViewDAO{

	public static List<UserVO>  getCustomerList()	  // display user information
	{
		String QueryList= "SELECT *  FROM IES_USER";
		Connection con=null;
		List<UserVO> custList= new ArrayList<UserVO>();
		try
		{
                  con =ConnectionDB.getDBConnection();
			PreparedStatement pStat= con.prepareStatement(QueryList);
			 
			 ResultSet  result=  pStat.executeQuery();
			 
			    while(result.next())
			    {
			    	 //result.getString("cid");
			    	String cId = result.getString(1);
			    	String cName = result.getString(2);
			    	String contactNumber = result.getString(3);
			    	UserVO  customer=new  UserVO(cId, cName,contactNumber);
			    	custList.add(customer);
			    	
			    }
			
			
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in fetching user details:"+ e);
		}
		catch(SQLException e)
		{
			System.out.println("please enter the correct query:"+e);
		}
		
		
		return custList;
		
	}
}