package org.birlasoft.customerportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import com.birlasoft.customrportal.model.OrderVO;
import com.birlasoft.customrportal.model.ProductVO;
import com.birlasoft.customrportal.util.ConnectionDB;

//DATA ACCESS LAYER
public class ProductDAO {

/* addProduct() : method to add  data in Product 
 * SearchProducttList() : method to search for specific product from given list
 * 
 */
	public static int addProduct(ProductVO product)
	{    int result=0;
		Connection con =null;
		String QUERY="insert into ies_product values(?,?,?)";
		try
		{
		ConnectionDB.loadDrivers();
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1, product.getProductId());
		                 pStat.setString(2, product.getProductName());
		                 pStat.setString(3, product.getProductPrice());
		                result= pStat.executeUpdate();
		                
		                 
		
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("Problem in connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("Problem in adding product details.Please enter correct product details:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}
	public static int SearchProducttList(ProductVO product)
	{   
		int result=0;
		Connection con=null;
		String QueryList= "SELECT *FROM IES_PRODUCT WHERE productId = ?  "+"";
		
		try {
			
			ConnectionDB.loadDrivers();
		} catch (CustomerDatabaseException e) {
			System.out.println("Problem in loading product");
		}
		try
		{
                  con =ConnectionDB.getDBConnection();
			PreparedStatement pStat= con.prepareStatement(QueryList);
			 
			 pStat.setString(1, product.getProductId());
			 result=pStat.executeUpdate();
			 
			  
			
			
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in fetching product:"+ e);
		}
		catch(SQLException e)
		{
			System.out.println("Problem in adding product details.Please enter correct product details:"+e);
		}
		finally {
			ConnectionDB.closeDBConnection(con);
		}
		
		
		return result;
		
	
}

	public static List<ProductVO> getCustomerList() {
		return null;
		// TODO Auto-generated method stub
		
	}

	
	
	
}
