package org.birlasoft.customerportal.dao;

public class CustomerDatabaseException extends Exception {
	
	
	public CustomerDatabaseException(String msg)
	{   
		super(msg);
		System.out.println("Problem while connecting to database");
		
	}
	public CustomerDatabaseException(Throwable error)
	{
		super(error);
		System.out.println("Syntax error");
	
		
	}
	 
	
	

}
