package org.birlasoft.customerportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import com.birlasoft.customrportal.model.OrderVO;
import com.birlasoft.customrportal.util.ConnectionDB;

//DATA ACCESS LAYER
public class OderDAO {

/* addCustomer() method : to add customer data in order or cart
 * getDBConnection() method : to connect with database
 * closeDBConnection() method : to close database connection
 * SearchOrderList() method : to search any order that you have added before
 * 
 */
	public static int addOrder(OrderVO order)
	{    int result=0;
		Connection con =null;
		String QUERY="insert into ies_order values(?,?,?)";
		try
		{
		ConnectionDB.loadDrivers();
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		              
		                 pStat.setString(1, order.getProductId());
		                 pStat.setString(2, order.getproductName1());
		                 pStat.setString(3, order.getproductColor());
		                result= pStat.executeUpdate();
		                
		                 
		
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("Problem in  database connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("Problem in adding details. Product is not available:  "+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}

	public static int deleteOrderList(OrderVO order)
	{   
		int result=0;
		Connection con=null;
		String QueryList= "DELETE FROM IES_ORDER WHERE productId = ?  "+"";
		
		try {
			
			ConnectionDB.loadDrivers();
		} catch (CustomerDatabaseException e) {
			System.out.println("Problem in loading order");
		}
		try
		{
                  con =ConnectionDB.getDBConnection();
			PreparedStatement pStat= con.prepareStatement(QueryList);
			 
			 pStat.setString(1, order.getProductId());
			 result=pStat.executeUpdate();
			 
			  
			
			
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in fetching order:"+ e);
		}
		catch(SQLException e)
		{
			System.out.println("Please Check your order present in the cart or not:"+e);
		}
		finally {
			ConnectionDB.closeDBConnection(con);
		}
		
		
		return result;
		
	}
	public static int SearchOrderList(OrderVO order)
	{   
		int result=0;
		Connection con=null;
		String QueryList= "SELECT *FROM IES_ORDER WHERE productId = ?  "+"";
		
		try {
			
			ConnectionDB.loadDrivers();
		} catch (CustomerDatabaseException e) {
			System.out.println("Problem in loading order");
		}
		try
		{
                  con =ConnectionDB.getDBConnection();
			PreparedStatement pStat= con.prepareStatement(QueryList);
			 
			 pStat.setString(1, order.getProductId());
			 result=pStat.executeUpdate();
			 
			  
			
			
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in fetching order:"+ e);
		}
		catch(SQLException e)
		{
			System.out.println("Please check the order details:"+e);
		}
		finally {
			ConnectionDB.closeDBConnection(con);
		}
		
		
		return result;
		
	}
}