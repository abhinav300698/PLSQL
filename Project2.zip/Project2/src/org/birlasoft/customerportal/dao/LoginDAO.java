package org.birlasoft.customerportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/*
 *  loginCheck() method: to check login username and password details
 *  getDBConnection() method : to connect with database
 */
 
import com.birlasoft.customrportal.model.LoginVO;
import com.birlasoft.customrportal.util.ConnectionDB;

public class LoginDAO {
	/*
	 * public static int loginCheck(LoginVO login) : validation of username and password
	 */
	
	public static int loginCheck(LoginVO login) throws LoginCheckException
	{    int result=0;
		Connection con =null;
		String QUERY="select user_name, password from login where user_name=? and password=?";//fetching login details from login table
		try
		{         
		ConnectionDB.loadDrivers();
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		System.out.println(""+login);
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1, login.getUserName().trim());
		                 pStat.setString(2, login.getPassword().trim());
		                  
		                ResultSet loginResult= pStat.executeQuery();
		                
		                if(loginResult.next())
		                	
		                {
		                	result=1;
		                	System.out.println("Verifying...!!");
		                }
		                else
		                {
		                	System.out.println("Incorrect username or password!!");
		                }
		                 
		
		}
		catch(CustomerDatabaseException e)
		{
			
			 throw new LoginCheckException(e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in connection:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		//System.out.println("result :"+result);
		return result;
	}
	

}
