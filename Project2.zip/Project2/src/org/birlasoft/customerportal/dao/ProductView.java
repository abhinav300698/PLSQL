package org.birlasoft.customerportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.birlasoft.customrportal.model.ProductVO;
import com.birlasoft.customrportal.util.ConnectionDB;

public class ProductView{
	  
	public static List<ProductVO>  getProductList()// display Product information
	{
		String QueryList= "SELECT * FROM IES_PRODUCT";
		Connection con=null;
		List<ProductVO> productList= new ArrayList<ProductVO>();
		try
		{
                  con =ConnectionDB.getDBConnection();
			PreparedStatement pStat= con.prepareStatement(QueryList);
			 
			 ResultSet  result=  pStat.executeQuery();
			 
			    while(result.next())
			    {
			    	 //result.getString("pid");
			    	String pid = result.getString(1);
			    	String pName = result.getString(2);
			    	String pPrice = result.getString(3);
			    	ProductVO  product=new  ProductVO(pid, pName,pPrice);
			    	productList.add(product);
			    	
			    }
			
			
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in fetching product details:"+ e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in query:"+e);
		}
		
		
		return productList;
		
	}
}