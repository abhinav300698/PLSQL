package org.birlasoft.customerportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.birlasoft.customrportal.model.OrderVO;
import com.birlasoft.customrportal.util.ConnectionDB;

public class OrderView{
/*
 * getOrderList() : method to display order details
 * 
 */
	public static List<OrderVO>  getOrderList()// display Order information
	{
		String QueryList= "SELECT *  FROM IES_ORDER";
		Connection con=null;
		List<OrderVO> orderList= new ArrayList<OrderVO>();
		try
		{
                  con =ConnectionDB.getDBConnection();
			PreparedStatement pStat= con.prepareStatement(QueryList);
			 
			 ResultSet  result=  pStat.executeQuery();
			 
			    while(result.next())
			    {
			    	 //result.getString("cid");
			    	String pId = result.getString(1);
			    	String pName = result.getString(2);
			    	String pcolor = result.getString(3);
			    	OrderVO  order=new  OrderVO(pId,pName,pcolor);
			    	orderList.add(order);
			    	
			    }
			
			
		}
		catch(CustomerDatabaseException e) // catch exception
		{
			System.out.println("problem in fetching order details:"+ e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in query:"+e);
		}
		
		
		return orderList;
		
	}
}