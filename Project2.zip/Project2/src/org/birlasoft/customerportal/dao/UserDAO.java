package org.birlasoft.customerportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import com.birlasoft.customrportal.model.ProductVO;
import com.birlasoft.customrportal.model.UserVO;
import com.birlasoft.customrportal.util.ConnectionDB;

//DATA ACCESS LAYER
public class UserDAO {

/* addCustomer method : to add customer data in user
 * Updateuser() method : to update user details
 */
	public static int addCustomer(UserVO customer)
	{    int result=0;
		Connection con =null;
		String QUERY="insert into ies_user values(?,?,?)";
		try
		{
		ConnectionDB.loadDrivers();
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in loading connection"+e);
		}
		
		try
		{
		con= ConnectionDB.getDBConnection();
		
		
		PreparedStatement pStat = con.prepareStatement(QUERY);
		                 pStat.setString(1, customer.getUserId());
		                 pStat.setString(2, customer.getUserName());
		                 pStat.setString(3, customer.getContactNumber());
		                result= pStat.executeUpdate();
		                
		                 
		
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in  database connection:"+e);
		}
		catch(SQLException e)
		{
			System.out.println("Problem in sql connection. Please enter the correct credentials:"+e);
		}
		finally
		{
			ConnectionDB.closeDBConnection(con);
		}
		
		return result;
	}
	
	public static int Updateuser(UserVO user)
	{   
		int result=0;
		Connection con=null;
		String QueryList= "UPDATE IES_USER SET userName='SHAM' WHERE userId = ?  "+"";
		
		try {
			
			ConnectionDB.loadDrivers();
		} catch (CustomerDatabaseException e) {
			System.out.println("Problem in loading user");
		}
		try
		{
                  con =ConnectionDB.getDBConnection();
			PreparedStatement pStat= con.prepareStatement(QueryList);
			 
			 pStat.setString(1, user.getUserId());
			 result=pStat.executeUpdate();
			 
			  
			
			
		}
		catch(CustomerDatabaseException e)
		{
			System.out.println("problem in updating profile:"+ e);
		}
		catch(SQLException e)
		{
			System.out.println("problem in updating profile . Please provide correct credentials :"+e);
		}
		finally {
			ConnectionDB.closeDBConnection(con);
		}
		
		
		return result;
		
	
}

	
		
	}

	
	
	

