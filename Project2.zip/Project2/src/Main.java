import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.birlasoft.customerportal.dao.UserDAO;

import org.birlasoft.customerportal.dao.LoginCheckException;
import org.birlasoft.customerportal.dao.LoginDAO;
import org.birlasoft.customerportal.dao.OderDAO;
import org.birlasoft.customerportal.dao.OrderView;
import org.birlasoft.customerportal.dao.ProductDAO;
import org.birlasoft.customerportal.dao.ProductView;

import org.birlasoft.customerportal.dao.ViewDAO;
import com.birlasoft.customrportal.model.LoginVO;
import com.birlasoft.customrportal.model.OrderVO;
import com.birlasoft.customrportal.model.ProductVO;
import com.birlasoft.customrportal.model.UserVO;
import com.birlasoft.customrportal.service.LoginBO;


public class Main {
/*
 * Menu Driven program for various menus like 1. USER MENU 2.PRODUCT MENU 3. ORDER MENU
 */
	
	public static void main(String[] args) {
	     
		
		     Scanner  input= new Scanner(System.in);
		   //Login Check for user authentication
	         String loginReq="yes";
	         int loginCheck=0;
	         
	         
	          LoginDAO loginDAO = new LoginDAO();
	         
		     while(loginReq.equalsIgnoreCase("yes"))
		     {
		    	 
		    	 
		    System.out.println("\n                                ***WELCOME TO IES ONLINE SHOPPING SYSTEM***                           ");	 	    	 
			System.out.println("                         _________________________________________________________                      ");	 
		    System.out.println("\nLOGIN ");	     
		    System.out.println("*******************************************************************");    	     
			System.out.println("\nPlease Enter Your Credientials ");	
				  
			System.out.println("\nPlease Enter  Name :");
			         String userName=input.nextLine();
			System.out.println("Please Enter Password :");   
			         String password=input.nextLine();
			         
			     LoginVO login = new LoginVO(userName,password);    
			         
				 boolean  loginValidate= LoginBO.loginValidate(login);
				  
				 if(loginValidate) // business logic success LoginBO
				 {					 try
					 {
					 loginCheck = LoginDAO.loginCheck(login);
					 }
					 catch(LoginCheckException e)
					 {
						 System.out.println(e);
					 }
					 if(loginCheck==1)
					 {
						 System.out.println("\n---login check sucesss---");
						 System.out.println("------------------------------------------------------------------");	 
						 break;
					 }
				 }
				 
				   System.out.println("LOGIN FAILED!!!\nPLEASE ENTER CORRECT CREDENTIALS ");
				   
				   
				   
				     }
			         boolean customerMenu=true;
				     while (customerMenu)
				     {
				     System.out.println(" \n\n                                 ***CUSTOMER SERVICES AVAILABLE***                                   ");
				     System.out.println("                         _________________________________________________________                      ");	 
				   
				     System.out.println("\nCUSTOMER SERVICES : ");
				     System.out.println("*******************************************************************");
				     System.out.println("\n");
				     System.out.println("*USER INFORMATION      : PRESS 1");
				     System.out.println("*PRODUCT INFORMATION   : PRESS 2");
				     System.out.println("*ORDER INFORMATION     : PRESS 3");
				     System.out.println("*EXIT                  : PRESS 4");
				      
				     int userSelection =input.nextInt();
			         
				     switch(userSelection)
				     
				     
				     {
				     
				     case 1:
				     {
				    	 System.out.println("                                         ***USER  MENU***                                                 ");
				    	 System.out.println("                        __________________________________________________                      ");
				    	    
				    	 
				     {
				     System.out.println("\nPLEASE SELECT OPTION BELOW :");
					 System.out.println("*******************************************************************");
					 System.out.println("\n ");
				  
				     System.out.println("*ADD USER INFORMATION          : PRESS 1");
				     System.out.println("*VIEW USER DETAILS             : PRESS 2");
				     System.out.println("*UPDATE USER DETAILS           : PRESS 3");
				     System.out.println("*EXIT                          : PRESS 4");
				    
				     System.out.println("------------------------------------------------------------------");	 
				     int customerCheck =input.nextInt();
			                  
			         
		               if(customerCheck==1)
		               {
				    	   System.out.println("ADD CUSTOMER DETAILS :");
				    	   System.out.println("*******************************************************************");
				    	   
				    	   //System.out.println("\nPlease Enter  Id :");
				    	   //String cid = input.nextLine();
				    	   
				    		   System.out.println("\nPlease Enter Valid Id :");
				    		 String  cid = input.next();
				    	  
				    	   
				    	
				    	
				    		   System.out.println("\nPlease Enter  Valid Name :");
				    		  String cName = input.next();
				    	  
				    	   
				    	  
				    		   System.out.println("\nPlease Enter Valid Contact Number :");
				    		String   cContact = input.next();
				    	
		    	   
		    		   

		    	   
				    	   UserVO customer = new UserVO(cid,cName,cContact);
				    	   
				    	  
				    	   
				    	  
				    		   //sending data to database
				    		   int daoResult=UserDAO.addCustomer(customer);
				    		   
				    		   if(daoResult>=1)
				    		   {
				    		   System.out.println("---USER DETAILS ADDED SUCCESSFULLY---");
				    		   }
				    		   else
				    		   {
				    			   System.out.println("PROBLEM IN ADDING INFORMATION ! PLEASE CHECK THE CREDENTIALS\n");
				    		   }
				    	 
				       
			               }
		               
		               if(customerCheck==2) {
		            	   
		 		    	  System.out.println("");
		 		    	  
		 		    	  
		 		    	  List<UserVO> custList=  ViewDAO.getCustomerList();
		 		    	  
		 		    	  System.out.println("\n\nCUSTOMER DETAILS :");
		 		    	 System.out.println("------------------------------------------------------------------");	
		 		    	  
		 		    	  for(UserVO customer1 : custList)
		 		    	  {
		 		    		  System.out.println(customer1);
		 		    	  }
		 		    	  
							
		               
					}
					
		               else  if(customerCheck==3)
		               {
		            	      System.out.println("Enter user ID");
		            	      String userId=input.next();
		            	      
		            	       UserVO user= new UserVO(userId);
		            	       int OrderResult =UserDAO.Updateuser(user);	  
			 		    	
			 		    	 if(OrderResult>=1)
                          {
                            System.out.println("---USER UPDATED SUCCESSFULLY---");
                          }
			 		    	 else 
                 	       {
                 		   System.out.println("---NOT UPDATED---");
                 	       }
			 		    	
		              }
		                if(customerCheck==4)
	            	   {
	            		   System.out.println("\n**THANK YOU FOR USING ONLINE SHOPPING**");
	            	   }  
		               
		    break;
		     }	     
		    }
		        
		     case 2:
		     {  
		    	 System.out.println("                                           ***PRODUCT MENU***                                                 ");
		    	 System.out.println("                        _________________________________________________________                      ");
		    	    
		    	 
		     {
		     System.out.println("\nPLEASE SELECT OPTION BELOW :");
			 System.out.println("*******************************************************************");
			 System.out.println("\n ");
		  
		     System.out.println("*ADD PROUDUCT    : PRESS 1");
		     System.out.println("*VIEW PRODUCT    : PRESS 2");
		     System.out.println("*SEARCH PRODUCT  : PRESS 3");
		     System.out.println("*EXIT            : PRESS 4");
		     
		     System.out.println("------------------------------------------------------------------");	 
		     int productCheck =input.nextInt();
	                  
	         
		               if(productCheck==1)
		               {
				    	   System.out.println("ADD PRODUCT DETAILS (BY SELLER):");
				    	   System.out.println("*******************************************************************");
				    	   
				    	   System.out.println("\nPlease Enter  Id :");
				    	   String pid= input.next();
				    	   System.out.println("\nPlease Enter  Name :");
				    	   String pName= input.next();
				    	   System.out.println("\nPlease Enter  Price:");
				    	   String pPrice= input.next();
				    	   
				    	   ProductVO product = new ProductVO(pid,pName,pPrice);
				    	   
				    	  
				    		  
				    		   //sending data to database
				    		   int daoResult=ProductDAO.addProduct(product);
				    		   
				    		   if(daoResult>=1)
				    		   {
				    		   System.out.println("---PRODUCT DETAILS ADDED SUCCESSFULLY---");
				    		   }
				    		   else
				    		   {
				    			   System.out.println("---PROBLEM IN ADDING PRODUCT! PLEASE CHECK THE CREDENTIALS---");
				    		   }
				    		   }
             
		               if(productCheck == 2) {
          	   
		    	  System.out.println("");
		    	  
		    	  
		    	  List<ProductVO> productList=  ProductView.getProductList();
		    	  
		    	  System.out.println("\n\nPRODUCT DETAILS :");
		    	 System.out.println("------------------------------------------------------------------");	
		    	  
		    	  for(ProductVO customer1 : productList)
		    	  {
		    		  System.out.println(customer1);
		    	  }
		    	  
			} 
		              
		               else if(productCheck==3)
		               {
		            	   
		            	   System.out.println("\nPlease Enter  Product ID:");
				    	   String productId= input.next();
				    	   
				    	   ProductVO product = new ProductVO(productId);
				    	   
				    	  
				    		  
				    		   //sending data to database
				    		   int daoResult=ProductDAO.SearchProducttList(product);
				    		   
				    		   if(daoResult>=1)
				    		   {
				    		   System.out.println("---PRODUCT DETAILS PRESENT IN RECORD---");
				    		   }
				    		   else
				    		   {
				    			   System.out.println("---PROBLEM IN SEARCHING PRODUCT! PLEASE CHECK THE CREDENTIALS---");
				    		   }
			 		    	  
					  }
		               if(productCheck==4)
	            	   {
	            		   System.out.println("\n**THANK YOU FOR USING ONLINE SHOPPING**");
	            	   }
		          
		     break;
		     }
		     
		    }               
		     case 3:
		     {
		    	 
		    	 System.out.println("                                             ***ORDER MENU***                                                 ");
		    	 System.out.println("                        _________________________________________________________                      ");
		    	    
		    	 
		     {
		     System.out.println("\nPLEASE SELECT OPTION BELOW :");
			 System.out.println("*******************************************************************");
			 System.out.println("\n ");
		  
		     System.out.println("*ADD ORDER      : PRESS 1");
		     System.out.println("*VIEW ORDER     : PRESS 2");
		     System.out.println("*DELETE ORDER   : PRESS 3");
		     System.out.println("*SEARCH ORDER   : PRESS 4");
		     System.out.println("*EXIT           : PRESS 5");
		    
		     System.out.println("------------------------------------------------------------------");	 
		     int orderCheck =input.nextInt();
	                  
	         
		               if(orderCheck==1)
		               {
		            System.out.println("\nPlease Enter  Id :");
				    String oId= input.next();
		    	   System.out.println("\nPlease Enter  Name :");
		    	   String pName= input.next();
		    	   System.out.println("\nPlease Enter  Color:");
		    	   String pcolor= input.next();
		    	   
		    	   OrderVO order = new OrderVO(oId,pName,pcolor);
		    	   
		    	  
		    		  
		    		   //sending data to database
		    		   int daoResult=OderDAO.addOrder(order);
		    		   
		    		   if(daoResult>=1)
		    		   {
		    		   System.out.println("---ORDER DETAILS ADDED SUCCESSFULLY---");
		    		   }
		    		   else
		    		   {
		    			   System.out.println("---PROBLEM IN ADDING ORDER! PLEASE CHECK THE CREDENTIALS---");
		    		   }
		     }
		               
		               if(orderCheck == 2) {
		              	   
		 		    	  System.out.println("");
		 		    	  
		 		    	  
		 		    	  List<OrderVO> orderList=  OrderView.getOrderList();
		 		    	  
		 		    	  System.out.println("\n\nORDER DETAILS :");
		 		    	 System.out.println("------------------------------------------------------------------");	
		 		    	  
		 		    	  for(OrderVO order1 : orderList)
		 		    	  {
		 		    		  System.out.println(order1);
		 		    	  }
		 		    	  
                }   
 		
               else if (orderCheck==3)
                   
		              
               {
           	      System.out.println("Enter order ID");
           	      String orderId=input.next();
           	      
           	       OrderVO order= new OrderVO(orderId);
           	       int OrderResult =OderDAO.deleteOrderList( order);	  
	 		    	
	 		    	 if(OrderResult>=1)
                    {
                      System.out.println("---ORDER REMOVED SUCCESSFULLY---");
                    }
	 		    	 else 
           	       {
           		   System.out.println("---NOT REMOVED---");
           	       }
	 		    	
             }  
            	  if(orderCheck==4)
               
		              
            		   {
            		  System.out.println("Enter order ID");
		            	      String orderId=input.next();
		            	      
		            	       OrderVO order= new OrderVO(orderId);
		            	       int OrderResult =OderDAO.SearchOrderList( order);	  
			 		    	
			 		    	 if(OrderResult>=1)
                             {
                               System.out.println("---ORDER IS PRESENT IN CART---");
                             }
			 		    	 else 
                    	       {
                    		   System.out.println("---CART IS EMPTY---");
                    	       }
			 		    	
		              }
            	   if(orderCheck==5)
            	   {
            		   System.out.println("\n**THANK YOU FOR USING ONLINE SHOPPING**");
            	   }
		               break;           
		 		
		     }
		     }
		     case 4:
		     {   System.out.println("----------------------------------------------------------------------------------------------");	
		    	 System.out.println("                                     ***THANK YOU***                                          ");
		    	 System.out.println("                                     HAVE A GREAT DAY                                         ");
		    	 System.out.println("----------------------------------------------------------------------------------------------");	
		    	 customerMenu=false;
		    break;
		     } 
		     } //end of switch
		     
		     }// end of while loop
	}
}